package cl.alonso.pioneerodyssey.core.slots;

public interface Slot {
    String getInfo();
    
}
