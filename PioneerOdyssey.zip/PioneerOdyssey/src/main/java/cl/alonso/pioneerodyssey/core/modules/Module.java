package cl.alonso.pioneerodyssey.core.modules;

public interface Module {
    String getInfo();
}
