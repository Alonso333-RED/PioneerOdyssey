package cl.alonso.pioneerodyssey.core.slots;

public class StructureSlot {
    
}
